package com.library.controller;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.model.LibraryUser;

public interface UserRepository extends JpaRepository<LibraryUser, Long> {


}

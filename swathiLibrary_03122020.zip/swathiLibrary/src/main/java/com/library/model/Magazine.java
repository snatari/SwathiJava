package com.library.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Magazine {

	@Id
	private String mTitle;
	private String publisher;
	private int mCopies;
	private String rRating;
	
	public Magazine() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Magazine(String mTitle, String publisher, int mCopies, String rRating) {
		super();
		this.mTitle = mTitle;
		this.publisher = publisher;
		this.mCopies = mCopies;
		this.rRating = rRating;
	}

	public String getmTitle() {
		return mTitle;
	}

	public void setmTitle(String mTitle) {
		this.mTitle = mTitle;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public int getmCopies() {
		return mCopies;
	}

	public void setmCopies(int mCopies) {
		this.mCopies = mCopies;
	}

	public String getrRating() {
		return rRating;
	}

	public void setrRating(String rRating) {
		this.rRating = rRating;
	}
	
	
	
}

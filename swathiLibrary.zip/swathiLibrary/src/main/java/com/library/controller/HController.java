package com.library.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.library.model.LibraryUser;
import com.library.controller.UserRepository;

@Controller
public class HController {

	@Autowired
	private UserRepository userRepository;

	@RequestMapping("home")
	public String getHome() {
		System.out.println("Hello World - home");
		return "home.jsp";
	}

	@RequestMapping(value = "/LoginRegister", params = "login", method = RequestMethod.POST)
	public String Login(ModelMap model, @RequestParam String username, @RequestParam String password) {

		System.out.println("Hello World - LoginRegister");

		if (username.isEmpty() && (password.isEmpty())) {
			model.put("errorMessage", "Please Enter Credentials");
			return "home";
		}

		if (username.isEmpty() || (password.isEmpty())) {
			model.put("errorMessage", "Please Enter Credentials - username or password is missing");
			return "home";
		}

		List<LibraryUser> userList = userRepository.findAll();

		for (LibraryUser l : userList) {

			LibraryUser tempUsr = new LibraryUser();
			if (l.getuName().equals(username) && (l.getPassword().equals(password))) {

				System.out.println("user provided vaild credentials");

				model.put("username", l.getfName());
				model.put("password", password);

				return "librarymain.jsp";

			} else {
				System.out.println("Please enter valid Credentials - username or password is not matching");
				model.put("errorMessage", "Please enter valid Credentials - username or password is not matching");
				return "home";
			}

		}

		return "home";
	}

	@RequestMapping(value = "/LoginRegister", params = "register", method = RequestMethod.POST)
	public String Register(ModelMap model, @RequestParam String name, @RequestParam String password) {
		System.out.println("Hello World - register");

		return "registration.jsp";

	}

	@RequestMapping(value = "/Registration", method = RequestMethod.POST)
	public String Registration(ModelMap model, @RequestParam String firstname, @RequestParam String lastname,
			@RequestParam String email, @RequestParam String addressL1, @RequestParam String addressL2,
			@RequestParam String State, @RequestParam String City, @RequestParam int ZipCode,
			@RequestParam String username, @RequestParam String password, @RequestParam String dob,
			@RequestParam long phone) {

		// LibraryUser(String uName, Long uID, String password, String fName, String
		// lName, String addLine1, String addLine2,
		// String aptNo, String city, int zipCode, Date dob, String email, long phoneNo)

		System.out.println("Hello World - registration (generating new user)");
		System.out.println("first name " + firstname);
		System.out.println("password " + password);
		System.out.println("date of birth " + dob);

		List<LibraryUser> userList = userRepository.findAll();
		boolean usrexsits = false;
		for (LibraryUser l : userList) {
			LibraryUser tempUsr = new LibraryUser();
			if (l.getuName().equals(username)) {
				usrexsits = true;
				System.out.println("user already exists");
				model.put("errorMessage", "user already exists.. please enter a new user name and try again");
				return "registration.jsp";

			}

		}

		if (!usrexsits) {
			userRepository.save(new LibraryUser(username, null, password, firstname, lastname, addressL1, addressL2,
					null, City, ZipCode, null, email, phone));
			model.put("name", firstname);
			model.put("password", password);

		}
		return "librarymain.jsp";
	}

}

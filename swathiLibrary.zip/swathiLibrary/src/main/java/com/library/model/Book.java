package com.library.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("app")
@Entity
public class Book {

	private String imgSrc;
	private String bTitle;
	@Id 
	private long ISBN;
	private String Author;
	private int bCopies;
	private String illustrator;
	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Book(String imgSrc, String bTitle, long iSBN, String author, int bCopies, String illustrator) {
		super();
		this.imgSrc = imgSrc;
		this.bTitle = bTitle;
		ISBN = iSBN;
		Author = author;
		this.bCopies = bCopies;
		this.illustrator = illustrator;
	}

	public String getImgSrc() {
		return imgSrc;
	}

	public void setImgSrc(String imgSrc) {
		this.imgSrc = imgSrc;
	}

	public String getbTitle() {
		return bTitle;
	}

	public void setbTitle(String bTitle) {
		this.bTitle = bTitle;
	}

	public long getISBN() {
		return ISBN;
	}

	public void setISBN(long iSBN) {
		ISBN = iSBN;
	}

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		Author = author;
	}

	public int getbCopies() {
		return bCopies;
	}

	public void setbCopies(int bCopies) {
		this.bCopies = bCopies;
	}

	public String getIllustrator() {
		return illustrator;
	}

	public void setIllustrator(String illustrator) {
		this.illustrator = illustrator;
	}
	
	
}
